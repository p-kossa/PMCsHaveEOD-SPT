# PMCsHaveEOD-SPT

This is an update of JustNU's [PMC Bots Have EOD Account](https://hub.sp-tarkov.com/files/file/991-pmc-bots-have-eod-account/) mod for SPT 3.8.0. All credit goes to JustNU.

Simple mod that makes all PMC bots have EOD accounts (color and icon) for a little bit of extra immersion.

Should be compatibile with anything.
